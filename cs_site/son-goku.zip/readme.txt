﻿=== Dragonball Adventure Cursor Set ===

By: HusenPo (http://www.rw-designer.com/user/38863)

Download: http://www.rw-designer.com/cursor-set/son-goku

Author's decription:

Goku, also known as Son Goku (孫 悟空?) in the original Japanese-language version[1] and in the English language manga, is a character and the protagonist of the Dragon Ball manga series written by Akira Toriyama. He is loosely based on Sun Wukong, a central character in the classical Chinese novel Journey to the West.[2] Goku is introduced as an eccentric, monkey-tailed boy who practices martial arts and possesses superhuman strength.[3] At first, Goku is believed to be an Earthling, but he is later revealed to be a member of an extraterrestrial warrior race called the Saiyans.[4]
In Dragon Ball, Goku trains himself in various martial arts at his home in the jungle. He meets Bulma who is searching for the Dragon Balls. Bulma notices Goku's power and asks Goku to join her after explaining the legend of the Dragon Balls. As Goku matures, he becomes one of universe's mightiest warriors and protects his adopted home planet, Earth from villains who wish to harm it. Goku is depicted as carefree and aloof when at ease but quickly serious and strategic-minded when fighting. Goku is able to concentrate his Ki and use it for devastatingly powerful energy-based attacks, the most prominent being his signature Kame Hame Ha technique, in which Goku launches a blue energy blast from his palms.
As the protagonist, Goku appears in most of the episodes, films, television specials, and OVAs of the anime series Dragon Ball, Dragon Ball Z and Dragon Ball Z GT, as well as many of the franchise's video games. Due to the series' international popularity, Goku has become one of the most recognizable and iconic anime characters in the world. Outside the Dragon Ball franchise, Goku has made cameo appearances in Toriyama's self-parody series Neko Majin Z, has been the subject of other parodies, and has appeared in special events. Goku's critical reception has been largely positive and he has been recognized as the greatest manga/anime character of all time.
http://en.wikipedia.org/wiki/Goku

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.